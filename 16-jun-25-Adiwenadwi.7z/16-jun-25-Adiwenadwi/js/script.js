console.log("Javascript is working");
function greet(){
const welcomeSpeech = document.getElementById("welcome-speech");
console.log(welcomeSpeech);
welcomeSpeech.innerHTML = "Selamat Datang di Website Matematik";
}

//function to calculate luas
//formula luas segitiga = 0.5 * alas * tinggi
function calcLuas(){
    //var errorMsg;
    const alas = parseFloat(document.getElementById("alas").value);
    const tinggi = parseFloat(document.getElementById("tinggi").value);
    console.log(alas, tinggi);
    //const errorMsg = document.getElementById(error-msg);
    const result = document.getElementById("result-luas");

    if(!alas || !tinggi || alas <=0 || tinggi <= 0){
        document.getElementById("error-msg").textContent="Mohon untuk di isi nilai > 0"
        document.getElementById("result-luas").textContent="Luas Segitiga = ";
        return;
    }else{
    const luas = 0.5 * alas * tinggi;
    document.getElementById("result-luas").textContent=`Luas Segitiga = ${luas}`;
    
    //result.textContent='Luas Segitiga adalah' $ {luas};
    document.getElementById("error-msg").textContent=``;
    console.log(luas);
    }
}

//function to calculate keliling
//formula keliling segitiga = sisiA + sisiB + sisiC
function calcKeliling(){
    
    const alas = parseFloat(document.getElementById("alas").value);
    const tinggi = parseFloat(document.getElementById("tinggi").value);
    console.log(alas, tinggi);
    //const errorMsg = document.getElementById(error-msg);
    const result = document.getElementById("result-luas");

    if(!alas || !tinggi || alas <=0 || tinggi <= 0){
        document.getElementById("error-msg").textContent="Mohon untuk di isi nilai > 0"
        document.getElementById("result-luas").textContent="Luas Segitiga = ";
        return;
    }else{
    const luas = 0.5 * alas * tinggi;
    document.getElementById("result-luas").textContent=`Luas Segitiga = ${luas}`;
    
    //result.textContent='Luas Segitiga adalah' $ {luas};
    document.getElementById("error-msg").textContent=``;
    console.log(luas);
    }
}

